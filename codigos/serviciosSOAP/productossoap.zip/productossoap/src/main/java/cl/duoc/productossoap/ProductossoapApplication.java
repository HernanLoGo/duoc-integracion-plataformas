package cl.duoc.productossoap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductossoapApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductossoapApplication.class, args);
	}

}
