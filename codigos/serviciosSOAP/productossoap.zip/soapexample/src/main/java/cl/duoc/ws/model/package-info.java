//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.0 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2025.05.13 a las 01:58:49 AM CLT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://duoc.cl/ws", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cl.duoc.ws.model;
