//
// Este archivo ha sido generado por Eclipse Implementation of JAXB v4.0.3 
// Visite https://eclipse-ee4j.github.io/jaxb-ri 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
//

@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://example.com/countries", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cl.duoc.countries.generated;
