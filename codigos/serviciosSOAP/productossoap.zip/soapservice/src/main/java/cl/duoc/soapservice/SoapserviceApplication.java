package cl.duoc.soapservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapserviceApplication.class, args);
	}

}
