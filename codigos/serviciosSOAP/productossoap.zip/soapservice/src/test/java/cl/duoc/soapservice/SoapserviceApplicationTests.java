package cl.duoc.soapservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
